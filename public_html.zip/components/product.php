<?php
$uri = $_SERVER["REQUEST_URI"];
$id_match = preg_grep("~^\d+~", preg_split("~/~", $uri));
if($id_match == null) {
    return null;

} else {
    require_once($_SERVER["DOCUMENT_ROOT"]. "/config/looper.php");
    require_once($_SERVER["DOCUMENT_ROOT"]. "/config/constants.php");
    require_once($_SERVER["DOCUMENT_ROOT"]. "/config/functions.php");
    require_once($_SERVER["DOCUMENT_ROOT"]. "/models/product.php");
    $id = array_values($id_match);
    $id = $id[count($id) - 1];
    $product = Product::withID($id);
    $photos = preg_split("~,~", $product->photos);
    $similar_products = $session->db->get_similar_products($product->id, $product->cat_id);
    $page = array();

    $tags = "";
    $page['title'] = fakeHtml($product->title);
    $page['meta-keywords'] = $product->cat_name.", ".fakeHtml($product->title);
    $page['meta-description'] = fakeHtml($product->description)." ➔ ".fakeHtml($product->title)." in Nigeria - ".$product->cat_name;
    $page['meta-url'] = HOST_ADDR.productLink($product->title, $product->id);
    $page['og-title'] = fakeHtml($product->title);
    $page['og-description'] = fakeHtml($product->description);
    $page["og-image-type"] = mimeFromFilename(preg_split("~,~", $product->photos)[0]);
    $page["og-image"] = HOST_ADDR.preg_split("~,~", $product->photos)[0];
    $page['body'] = '
    <!--Grid row-->
      <div class="row wow fadeIn section">

        <!--Grid column-->
        <div class="col-md-6 mb-4">
        <!--Carousel Wrapper-->
        <div id="carousel-thumb" class="carousel slide carousel-fade carousel-thumbnails" data-ride="carousel">
          <!--Slides-->
          <div class="carousel-inner" role="listbox">
            '.(new Looper($photos))->loop("carousel-images").'
          </div>
          <!--/.Slides-->
          <!--Controls-->
          <a class="carousel-control-prev" href="#carousel-thumb" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carousel-thumb" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
          <!--/.Controls-->
          <ol class="carousel-indicators relative">
            '.(new Looper($photos))->fillFromObject(array("target" => "carousel-thumb", "maxthumbs" => 3), true)->loop("carousel-thumbs").'
          </ol>
        </div>
        <!--/.Carousel Wrapper-->

        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-6 mb-4">

          <!--Content-->
          <div class="p-4">

            <div class="mb-3 lead font-weight-bold">'.fakeHtml($product->title).'</div>

            <p class="lead">
              <span class="mr-1">
                <del>'.$MONEY_SYMBOLS["naira"].' <span data-type="number">'.($product->price + ceil(($product->price * DISCOUNT)/100)).'</span></del>
              </span>
              '.$MONEY_SYMBOLS["naira"].' <span data-type="number">'.$product->price.'</span><span class="scale"> per '.fakeHtml($product->scale).'</span>
            </p>

            <p class="lead font-weight-bold">Description</p>

            <p>'.fakeHtml($product->description).'</p>

            <div class="row">
              <!-- Default input -->
              <div class="col-sm-6" style="padding:10px">
                <button class="w-5 btn btn-primary btn-md" onClick="addOrRemove()" data-in-cart="0" data-in-text="Remove" data-out-text="Add to cart">
                    <i class="fa fa-shopping-cart ml-1"></i>
                </button>
              </div>
              <div class="col-sm-6" style="padding:10px">
                <button class="w-5 btn btn-warning btn-md" onClick="byNow()">By Now
                    <i class="fa fa-shopping-cart ml-1"></i>
                </button>
              </div>
            </div>

            <div class="col-sm-4s" style="padding:10px">
              <button class="w-5 btn btn-success btn-md" data-call="'.CONTACT_NUMBER.'" data-call-class="fa fa-phone-square ml-1">Call Us
                  <i class="fa fa-phone-square ml-1"></i>
              </button>
            </div>

            <hr>
            <label>Share with: </label>
            <span class="fa-round">
              <a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u='.urlencode($page['meta-url']).'" class="btn-floating fa fa-facebook"></a>
              <a target="_blank" href="https://twitter.com/share?via='.TWITTER_USER.'&text='.urlencode($product->title.": ".$product->description).'&url='.urlencode($page['meta-url']).'&hashtags='.urlencode($tags).'" class="btn-floating fa fa-twitter"></a>
              <a target="_blank" href="mailto:subject='.urlencode($product->title).'&body='.urlencode($product->title.": ".$product->description." at ".$page['meta-url']).'" class="btn-floating fa fa-envelope"></a>
              <a target="_blank" data-action="share/whatsapp/share" href="whatsapp://send?text='.urlencode("*".$product->title.":* ".$product->description." - _".$page['meta-url']."_").'" class="btn-floating fa fa-whatsapp"></a>
            </span>
          </div>
          <!--Content-->

        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->
    ';
if(count($similar_products["list"]) > 0) {
  $page["body"] .= '
  <p class="lead font-weight-bold">Similar products</p>
  <div class="row">
    '.(new Looper($similar_products["list"]))->loop("products").'
  </div>
  ';
}
$page['script'] = '
<script>
const productId = '.$product->id.';
const product = JSON.parse(\''.json_encode($product).'\');
$(document).ready(function(){
    updateCartState(isInCart(productId));
});
byNow = () => {
    addToCart(product);
    updateCartState(isInCart(productId));
    showCart();
}
addOrRemove = () => {
    if(isInCart(productId)) {
        removeFromCart(product);

    } else {
        addToCart(product);
    }
}
updateCartState = (isInCart) => {
    $.each($(\'[data-in-cart="1"], [data-in-cart="0"]\'), function(index, el) {
        $(this).attr("data-in-cart", isInCart?1:0);
    });
}
</script>
';
return $page;
}
<?php
$page = array();
$page['title'] = "Page Not Found";
$page['body'] = '
<div class="container-fluid">
    404 page Not Found!
</div>
';
$page['body-alone'] = true;
return $page;
?>
<?php
require_once($_SERVER["DOCUMENT_ROOT"]. "/config/looper.php");
require_once($_SERVER["DOCUMENT_ROOT"]. "/config/functions.php");
$pg = $_GET["pg"];
$searchPhrase = $_GET["search"];
$catId = $_GET["cat_id"];
$products = $session->db->get_products($pg, $searchPhrase, $catId);
$description = null;
if((isset($searchPhrase) && !empty($searchPhrase)) || $products['cat_description']) {
    if(isset($searchPhrase) && !empty($searchPhrase)) {
        $description = "Search reult for ".fakeHtml($searchPhrase);

    } else {
        $description = $products['cat_description'];
    }
}
$pg = !isset($_GET["pg"])? 0 : (int)$_GET["pg"];
if($pg == 0) $pg = 1;
$prev = $pg - 1;
$next = $pg + 1;
$catId = intval($_GET["cat_id"]);
$search = $_GET["search"];

$prevStyle = $prev < 1? " hide" : "";

$page = array();
$page["title"] = "Home Page";
$page["body"] = '
<section>
    <h2 class="text-center margin-bottom-10">'.($products['cat_name']?$products['cat_name'].' for sale':'Latest Products').'</h2>'
        .($description?'<p class="subtitle">'.$description.'</p>':'')
        .($products["list"]?
        '
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;" class="rows">
        '.(new Looper($products["list"]))->loop("products").'
        </div>
        '
        :
        '<div class="h-centerItem" style="margin-top:20px;">
                <div class="b-empty-cart-info">
                    <img alt="" class="h-mb-10 h-rl-15" src="/res/images/static/no_ads.png">
                    <p>No result found.<br>Please try widening your search.</p>
                </div>
        </div>').
    '
</section>
<nav'.($products["list"] && sizeOf($products["list"]) == PRODUCTS_PER_PAGE?'': ' class="hide"').' style="display:flex;justify-content:center;" aria-label="Page navigation example">
  <ul class="pagination">
    <li style="width:100px" class="page-item'.$prevStyle.'">
      <a class="page-link" href="/?pg='.strval($prev).'&cat_id='.strval($catId).'&search='.fakeHtml($search).'" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
        <span class="sr-only">Previous</span>
      </a>
    </li>
    <li style="width:100px;" class="page-item'.$nextStyle.'">
      <a style="display:flex;justify-content:end" class="page-link" href="/?pg='.strval($next).'&cat_id='.strval($catId).'&search='.fakeHtml($search).'" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>
  </ul>
</nav>
';
return $page;
?>
<?php
$page = array();
$page['title'] = "Checkout";
$page['body'] = '

        <p style="padding-top: 30px">Fill the form below to place your order. We will reach you by call or email within 24 hours of placing the order.</p>
        <form style="max-width:600px;padding:10px;" method="POST">
            <div class="form-group row">
              <label for="email" class="col-md-12" required="required">Email:</label>
              <div class="col-md-12">
                <input data-form="checkout" type="text" data-type="text" name="email" class="form-control" id="email" aria-describedby="email" placeholder="Enter your email">
              <div id="email-error" data-error="" class="error"></div>
              </div>
            </div>
            
            <div class="form-group row">
              <label for="number" class="col-md-12" required="required">Number:</label>
                <div class="col-md-12">
                  <input data-form="checkout" type="text" data-type="phone-number" name="number" class="form-control" id="number" aria-describedby="number" placeholder="Enter phone number">
                <div id="number-error" data-error="" class="error"></div>
              </div>
            </div>

            <div class="form-group row">
              <label for="message" class="col-md-12" required="required">Additional message(optional):</label>
              <div class="col-md-12">
                <textarea data-form="checkout" rows="4" style="resize:none;" data-type="text" name="message" class="form-control" id="message" aria-describedby="message" placeholder="You can tell us something here..."></textarea>
                <div id="message-error" data-error="" class="error"></div>
              </div>
            </div>
            <hr>
            <button id="submit" type="submit" class="btn btn-success" data-sending="false" data-text="Place order" data-text-sending="Please wait..."></button>
          </form>
';
$page["script"] = '
<script>
const data = {};
$(document).ready(function(){
    $.each($(\'[data-form="checkout"]\'), function(){
        data[[$(this).attr("name")]] = null;
    });

    $("form").submit(function(e){
        submit(e);
    });
    
    $("input, textarea").change(function(e){
        handleChange(e);
    });
    data.message = " ";
});
handleChange = (e) => {
    data[e.target.name] = e.target.value;
}
submit = (e) => {
    e.preventDefault();
    clearErrors();
    if($("#submit").data("sending") == true)return;
    const keys = Object.keys(data);
    var hasErrors = false;
    for (const key of keys) {
        console.log("key", key, data[[key]]);
        if(data[[key]] == null || data[[key]].length == 0) {
            hasErrors = true;
            var errorStart = key.replace(/([-_])/g, " ");
            setError(key, errorStart+" cannot be empty");
        }
    }

    if(data.message.length > 200) {
        hasErrors = true;
        setError("message", "Your message has exceeded 200 characters. Please shorten the message");
    }

    if(!hasErrors) {
        $("#submit").attr("data-sending", true);
        $("#submit").data("sending", true);
        const formData = new FormData();
        formData.append("data", JSON.stringify(data));
        formData.append("product_ids", LOCAL_STORAGE.getItem(CART));
        formData.append("captcha", "tetet");
        $.ajax({
            url: "/api/v1/orders/insert.php",
            data: formData,
            type: "POST",
            cache: false,
            processData: false,
            contentType: false,
            success: function(data, textStatus, jqXHR)
            {
                console.log("Data: " + data + "\nStatus: " + status);
                result = data;
                console.log("REZ", result, result.errors, result.errors.length);
                if(result.success) {
                    clearCart();
                    modalAlert("Your order has been placed. We will reach you soon.<br/><i>Thanks</i> You can also call us on <b>'.CONTACT_NUMBER.'</b>", function(){
                    });

                }else if(result.errors && Object.keys(result.errors).length > 0) {
                    const keys = Object.keys(result.errors);console.log("ERRORS", keys);
                    for (const key of keys) {
                        console.log("ERROR_KEY", key, result.errors[[key]]);
                        setError(key.split("-")[0], result.errors[[key]]);
                    }

                } else if(result.error) {
                    if(result.auth_required) {
                        document.location.href = "/signin";

                    } else {
                        modalAlert(result.error, function(){
                        });
                    }
                    console.log("ERROR", result.error);
                }
                $("#submit").attr("data-sending", false);
                $("#submit").data("sending", false);
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                modalAlert(errorThrown, function() {
                });
                $("#submit").attr("data-sending", false);
                $("#submit").data("sending", false);
            } 
        });
    }
}
</script>
';
return $page;
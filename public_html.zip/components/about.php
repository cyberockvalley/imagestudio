<?php
$page = array();
$page['title'] = "About Us";
$page['body'] = '
<h1 style="padding-top:20px">About Us</h1>
<p>
    Welcome to Dav&Dan Goshen Livestock Farms(dandavfarm), your number one source for all things agricultural products. We\'re dedicated to providing you the very best of agricultural products, with an emphasis on quality, affordability, and great return on investment.
</p>
<p>
Founded in 2019 by Olufunmilayo Adeleke, Dav&Dan Goshen Livestock Farms(dandavfarm) has come a long way from its beginnings in Ibadan, Nigeria. When Olufunmilayo Adeleke first started out, her passion for eco-friendly agricultural products drove her to start her own business.
</p>
<p>
We hope you enjoy our products as much as we enjoy offering them to you. If you have any questions or comments, please don\'t hesitate to contact us.<br/>

Sincerely,
</p>
<p>
Olufunmilayo Adeleke.
</p>
';
return $page;
?>
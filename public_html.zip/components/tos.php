<?php
$page = array();
$page['title'] = "Terms of Services";
$page['body'] = '
';
return $page;
?>
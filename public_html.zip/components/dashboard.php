<?php
require_once($_SERVER["DOCUMENT_ROOT"]. "/config/looper.php");
require_once($_SERVER["DOCUMENT_ROOT"]. "/config/constants.php");
$page = array();
$page['title'] = "Dashboard";
$page['body'] = '
<section>
    <nav>
        <div class="nav nav-tabs" id="nav-tab" role="tablist">
            <a class="nav-item nav-link active" id="nav-upload-tab" data-toggle="tab" href="#nav-upload" role="tab" aria-controls="nav-upload" aria-selected="true">Upload</a>
            <a class="nav-item nav-link" id="nav-add-cat-tab" data-toggle="tab" href="#nav-add-cat" role="tab" aria-controls="nav-add-cat" aria-selected="false">Add Cat</a>
            <a class="nav-item nav-link" id="nav-orders-tab" data-toggle="tab" href="#nav-orders" role="tab" aria-controls="nav-orders" aria-selected="false">Orders</a>
            <a class="nav-item nav-link" id="nav-settings-tab" data-toggle="tab" href="#nav-settings" role="tab" aria-controls="nav-settings" aria-selected="false">Settings</a>
        </div>
    </nav>
    <div class="tab-content" style="margin:15px;max-width:550px" id="nav-tabContent">
        <div class="tab-pane fade show active" id="nav-upload" role="tabpanel" aria-labelledby="nav-upload-tab">
          <form name="upload" method="POST">
            <div class="form-group row">
              <label for="title" class="col-md-2" required="required">Title:</label>
              <div class="col-md-10">
                <input data-form="upload" type="text" data-type="text" name="title" class="form-control" id="title" aria-describedby="title" placeholder="Enter title">
              <div id="title-error" data-error="" class="error"></div>
              </div>
            </div>
            <div class="form-group row">
              <label for="description" class="col-md-2" required="required">Desription:</label>
              <div class="col-md-10">
                <textarea data-form="upload" rows="4" style="resize:none;" data-type="text" name="description" class="form-control" id="description" aria-describedby="description" placeholder="Enter description"></textarea>
              <div id="description-error" data-error="" class="error"></div>
              </div>
            </div>
            <div class="form-group row">
              <label for="category" class="col-md-2">Category:</label>
              <div class="col-md-10">
              <select data-form="upload" data-type="text" class="form-control" id="category" name="category" required="required">
                <option>--Select category--</option>
                '.(new Looper($session->db->get_cats()["list"]))->loop("cats").'
              </select>
              <div id="category-error" data-error="" class="error"></div>
              </div>
            </div>
            <div class="form-group row">
              <label for="price" class="col-md-2" required="required">Price (&#8358;):</label>
                <div class="col-md-10">
                  <input data-form="upload" type="text" data-type="number" name="price" class="form-control" id="price" aria-describedby="price" placeholder="Enter price">
                <div id="price-error" data-error="" class="error"></div>
              </div>
            </div>
            <div class="form-group row">
              <label for="scale" class="col-md-2">Scale:</label>
              <div class="col-md-10">
                <select data-form="upload" data-type="text" class="form-control" id="scale" name="scale" required="required">
                  <option>--Select scale--</option>
                  <option>KG</option>
                  <option>LB</option>
                  <option>Head</option>
                  <option>Liter</option>
                  <option>CL</option>
                </select>
                <div id="scale-error" data-error="" class="error"></div>
              </div>
            </div>
            <div class="custom-control custom-checkbox mb-3">
                <input data-form="upload" id="nego" data-type="text" name="nego" value="1" type="checkbox" class="custom-control-input" id="nego" checked>
                <label class="custom-control-label" for="nego">Negotiable</label>
            </div>
            <hr>
            <div class="form-group mt-3">
                <div class="file-upload-wrapper">
                    <div class="card card-body view file-upload">
                        <div class="card-text file-upload-message">
                            <p>Click to add images<span class="xs-hide sm-hide-down"> or drag and drop images</p>
                            <i class="fa fa-cloud-upload fa-3x" aria-hidden="true"></i>
                        </div>
                        <input data-form="upload" id="file" name="product_photos" data-type="array" type="file" class="file_uploads" accept="image/*" multiple/>
                    </div>
                </div>
            </div>
            <label id="file-upload-preview-space" class="file-upload-preview-space" data-used="0" data-left="'.(MAX_TOTAL_IMAGE_SIZE_IN_MB * 1024).'"></label>
            <div id="product_photos-error" data-error="" class="error"></div>
            <div id="preview-area" class="row"></div>
            <hr>
            <button id="submit" type="submit" class="btn btn-success" data-sending="false" data-text="Submit" data-text-sending="Please wait..."></button>
          </form>
        </div>
        <div class="tab-pane fade" id="nav-add-cat" role="tabpanel" aria-labelledby="nav-add-cat-tab">
            <p class="lead">Add new category</p>
            <form name="add-cat" method="POST">
              <div class="form-group row">
                <label for="category_name" class="col-md-2" required="required">Name:</label>
                <div class="col-md-10">
                  <input data-form="add-cat" type="text" data-type="text" name="category_name" class="form-control" id="category_name" aria-describedby="category_name" placeholder="Category">
                  <div id="category_name-error" data-error="" class="error"></div>
                </div>
              </div>
              <div class="form-group row">
                <label for="category_description" class="col-md-2" required="required">Info:</label>
                <div class="col-md-10">
                  <textarea data-form="add-cat" rows="4" style="resize:none;" data-type="text" name="category_description" class="form-control" id="category_description" aria-describedby="category_description" placeholder="Enter description"></textarea>
                  <div id="category_description-error" data-error="" class="error"></div>
                </div>
              </div>
              <hr>
              <button id="add-cat" type="submit" class="btn btn-success" data-sending="false" data-text="Submit" data-text-sending="Please wait..."></button>
            </form>
        </div>
        <div class="tab-pane fade" id="nav-orders" role="tabpanel" aria-labelledby="nav-orders-tab">
          <div class="">
            <p>Orders empty.<br>No one has ordered a product yet.</p>
          </div>
        </div>
        <div class="tab-pane fade" id="nav-settings" role="tabpanel" aria-labelledby="nav-settings-tab">
            <p class="lead">Change password</p>
            <form name="change-password" method="POST">
              <div class="form-group row">
                <label for="password" class="col-md-2" required="required">Password:</label>
                <div class="col-md-10">
                  <input data-form="change-password" type="password" data-type-change-pass="text" name="password" class="form-control" id="password" aria-describedby="password" placeholder="Enter password">
                  <div id="password-error" data-error="" class="error"></div>
                </div>
              </div>
              <div class="form-group row">
                <label for="new_password" class="col-md-2" required="required">New Password:</label>
                <div class="col-md-10">
                  <input data-form="change-password" type="password" data-type-change-pass="text" name="new_password" class="form-control" id="new_password" aria-describedby="new password" placeholder="Enter new password">
                  <div id="new_password-error" data-error="" class="error"></div>
                </div>
              </div>
              <hr>
              <button id="submit-password" type="submit" class="btn btn-success" data-sending="false" data-text="Submit" data-text-sending="Please wait..."></button>
            </form>
        </div>
    </div>
</section>
';
$page['script'] = '
<script>
var totalImageSize = 0;
const inputsData = {};
const catData = {}
const passwordData = {};
$(document).ready(function(){
  //set the inputsData keys
  $.each($(\'[data-type="text"], [data-type="number"]\'), function(index, el) {
    if($(this).attr("data-form") == "upload") {
      inputsData[[$(this).attr("name")]] = null;
    }
  });
  $.each($(\'[data-type="array"]\'), function(index, el) {
    if($(this).attr("data-form") == "upload") {
      inputsData[[$(this).attr("name")]] = [];
    }
  });
  inputsData["nego"] = "checked";

  //password form
  $.each($(\'[data-type-change-pass="text"], [data-type-change-pass="number"]\'), function(index, el) {
    passwordData[[$(this).attr("name")]] = null;
  });

  //cat form
  $.each($(\'[data-form="add-cat"]\'), function(index, el) {
    catData[[$(this).attr("name")]] = null;
  });

  $("input, select, textarea").change(function(e) {
    handleChange(e);
  });
  $("form").submit(function(e){
    console.log("FormName: "+JSON.stringify(e.target.name));
    if(e.target.name == "upload") {
      submit(e);

    } else if(e.target.name == "add-cat") {
      submitCat(e);
      
    } else if(e.target.name == "change-password") {
      submitPassword(e);
      
    }
    
  });
});
$(document).on("click", ".fa-trash-o", function(e) {
    var $this = $(this);
    var index = $this.data("index");
    var image = inputsData["product_photos"][index];
    totalImageSize -= image.size;
    inputsData["product_photos"].splice(index, 1);
    updatePreview();
});
handleChange = (e) => {
  var type = e.target.type;
  const form = e.target.getAttribute("data-form");
  switch(type) {
    case "checkbox":
      if(form == "upload"){
        inputsData[e.target.name] = e.target.checked?"checked":null;

      } else if(form == "change-password"){
        passwordData[e.target.name] = e.target.checked?"checked":null;

      } else if(form == "add-cat"){
        catData[e.target.name] = e.target.checked?"checked":null;

      }
      break;
    case "file":
      if(form == "upload"){
        addFiles(e.target.files);
        updatePreview();

      }
      break;
    default:
      if(form == "upload"){
        inputsData[e.target.name] = e.target.value;

      } else if(form == "change-password"){
        passwordData[e.target.name] = e.target.value;

      } else if(form == "add-cat"){
        catData[e.target.name] = e.target.value;

      }
    break;
  }
}
addFiles = (files) => {
  $("#product_photos-error").attr("data-error", "");
  var errorType = 0;
  var errorSize = 0;
  const MAX_TOTAL_IMAGE_SIZE_IN_MB = '.MAX_TOTAL_IMAGE_SIZE_IN_MB.';
  for(var i = 0; i < files.length; i++) {
    var file = files[i];
    if(file.type != "image/jpeg" && file.type != "image/jpg" && file.type != "image/png"){
      errorType++;

    } else if((totalImageSize + file.size) / (1024 * 1024) > MAX_TOTAL_IMAGE_SIZE_IN_MB) {
      errorSize++;

    } else {
      console.log("inputsData", 152, inputsData);
      inputsData["product_photos"].push(file);
      console.log("size", 1, totalImageSize);
      console.log("size", 2, file.size);
      totalImageSize += file.size;
      console.log("size", 3, totalImageSize);
      
    }
    if(errorType > 0) {
      var error = "Only files ending with .jpg, .jpeg, .png are supported.";
      if(errorType > 1) { 
        error += " Some of your images are not supported.";
      } else {
        error += " Your image is not supported.";
      }
      $("#product_photos-error").attr("data-error", error);

    } else if(errorSize > 0) {
      $("#product_photos-error").attr("data-error", "You\'ve ran out of space. Consider deleting some images to create space for new ones.");
    }
  }
}
updatePreview = () => {
  $("#preview-area").html("");
  inputsData["product_photos"].forEach((item, index) => {
    $("#preview-area").append(
    \'<div class="col-sm-6 col-md-3 card file-upload-preview" style="background-image: url(\'+URL.createObjectURL(item)+\'">\'+
        \'<i data-index="\'+index+\'" class="fa fa-trash-o"></i>\'+
    \'</div>\');
  });
  var used = Math.round(totalImageSize/(1024));
  var left = '.(MAX_TOTAL_IMAGE_SIZE_IN_MB * 1024).' - used;
  $("#file-upload-preview-space").attr("data-used", used);
  $("#file-upload-preview-space").attr("data-left", left);
}


submitCat = (e) => {
  e.preventDefault();
  clearErrors();
  var sending = $("#add-cat").data("sending");
  if($("#add-cat").data("sending") == true)return;

  const keys = Object.keys(catData);console.log(keys);
  var hasErrors = false;
  for (const key of keys) {
    console.log("key", key, catData[[key]]);
    if(catData[[key]] == null || catData[[key]].length == 0) {
      hasErrors = true;
      var errorStart = key.replace(/([-_])/g, " ");
      setError(key, errorStart+" cannot be empty");
    }
  }

  if(!hasErrors) {
    $("#add-cat").attr("data-sending", true);
    $("#add-cat").data("sending", true);
    var formData = new FormData();
    formData.append("body", JSON.stringify(catData));
    $.ajax({
      url: "/api/v1/cats/add-new.php",
      data: formData,
      type: "POST",
      cache: false,
      processData: false,
      contentType: false,
      success: function(data, textStatus, jqXHR)
      {
        console.log("Data: " + data + "\nStatus: " + status);
        result = data;
        console.log("REZ", result);
        if(result.success) {
          modalAlert("New category added. Reload page to see changes.", function(){
          });
        }else if(result.errors && Object.keys(result.errors).length > 0) {
          const keys = Object.keys(result.errors);console.log(keys);
          for (const key of keys) {
            console.log("key", key, result.errors[[key]]);
            setError(key.split("-")[0], result.errors[[key]]);
          }

        } else if(result.error) {
          if(result.auth_required) {
            document.location.href = "/signin";

          } else {
            modalAlert(result.error, function(){
            });
          }
          console.log("ERROR", result.error);
        }
        $("#add-cat").attr("data-sending", false);
        $("#add-cat").data("sending", false);
      },
      error: function (jqXHR, textStatus, errorThrown)
      {
        modalAlert(errorThrown, function() {
        });
        $("#add-cat").attr("data-sending", false);
        $("#add-cat").data("sending", false);
      }
    });
  }
}

submitPassword = (e) => {
  e.preventDefault();
  clearErrors();
  var sending = $("#submit-password").data("sending");
  if($("#submit-password").data("sending") == true)return;

  const keys = Object.keys(passwordData);console.log(keys);
  var hasErrors = false;
  for (const key of keys) {
    console.log("key", key, passwordData[[key]]);
    if(passwordData[[key]] == null || passwordData[[key]].length == 0) {
      hasErrors = true;
      var errorStart = key.replace(/([-_])/g, " ");
      setError(key, errorStart+" cannot be empty");
    }
  }

  if(!hasErrors) {
    $("#submit-password").attr("data-sending", true);
    $("#submit-password").data("sending", true);
    var formData = new FormData();
    formData.append("body", JSON.stringify(passwordData));
    $.ajax({
      url: "/api/v1/users/change-password.php",
      data: formData,
      type: "POST",
      cache: false,
      processData: false,
      contentType: false,
      success: function(data, textStatus, jqXHR)
      {
        console.log("Data: " + data + "\nStatus: " + status);
        result = data;
        console.log("REZ", result);
        if(result.success) {
          modalAlert("Your password has been updated", function(){
          });
        }else if(result.errors && Object.keys(result.errors).length > 0) {
          const keys = Object.keys(result.errors);console.log(keys);
          for (const key of keys) {
            console.log("key", key, result.errors[[key]]);
            setError(key.split("-")[0], result.errors[[key]]);
          }

        } else if(result.error) {
          if(result.auth_required) {
            document.location.href = "/signin";

          } else {
            modalAlert(result.error, function(){
            });
          }
          console.log("ERROR", result.error);
        }
        $("#submit-password").attr("data-sending", false);
        $("#submit-password").data("sending", false);
      },
      error: function (jqXHR, textStatus, errorThrown)
      {
        modalAlert(errorThrown, function() {
        });
        $("#submit-password").attr("data-sending", false);
        $("#submit-password").data("sending", false);
      }
    });
  }
}
submit = (e) => {
  e.preventDefault();
  var sending = $("#submit").data("sending");
  clearErrors();
  console.log(sending);
  if($("#submit").data("sending") == true)return;
  console.log("data", inputsData);
  const keys = Object.keys(inputsData);console.log(keys);
  var hasErrors = false;
  for (const key of keys) {
    console.log("key", key, inputsData[[key]]);
    if(inputsData[[key]] == null || inputsData[[key]].length == 0) {
      hasErrors = true;
      var errorStart = key.replace(/([-_])/g, " ");
      setError(key, errorStart+" cannot be empty");
    }
  }

  console.log("HasErrors", hasErrors);
  
  if(!hasErrors) {
    $("#submit").attr("data-sending", true);
    $("#submit").data("sending", true);
    var formData = new FormData();
    console.log("inputsData", inputsData);
    for(var i = 0; i < inputsData["product_photos"].length; i++){
      formData.append("photo[]", inputsData["product_photos"][i]);
    }
    const body = Object.keys(inputsData).reduce((object, key) => {
      if(key != "product_photos"){object[key] = inputsData[key];}
      return object;
    }, {});
    formData.append("body", JSON.stringify(body));
    
    $.ajax({
      url: "/api/v1/products/upload.php",
      data: formData,
      type: "POST",
      cache: false,
      processData: false,
      contentType: false,
      success: function(data, textStatus, jqXHR)
      {
        console.log("Data: " + data + "\nStatus: " + status);
        var result = data;
        console.log("result", result);
        if(result.success && result.product) {
          document.location.href = productLink(result.product.title, result.product.id);

        }else if(result.errors) {
          const keys = Object.keys(result.errors);console.log(keys);
          for (const key of keys) {
            console.log("key", key, result.errors[[key]]);
            setError(key.split("-")[0], result.errors[[key]]);
          }

        } else if(result.error) {
          console.log("ERROR", result.error);
          if(result.auth_required) {
            document.location.href = "/signin";

          } else {
            modalAlert(result.error, function(){
            });
          }
        }
        $("#submit").attr("data-sending", false);
        $("#submit").data("sending", false);
      },
      error: function (jqXHR, textStatus, errorThrown)
      {
        console.log("error: " + errorThrown + "\nStatus: " + textStatus);
        modalAlert(errorThrown, function() {
        });
        $("#submit").attr("data-sending", false);
        $("#submit").data("sending", false);
      }
    });

  }
}
</script>
';
return $page;
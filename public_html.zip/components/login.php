<?php
$user_error_hide = " hide";
$password_error_hide = " hide";
$user_error = "";
$password_error = "";
$userText = "";
$passwordText = "";
if(isset($_POST["submit"])) {
    $user = $_POST["user"];
    $password = $_POST["password"];
    $rememberMe = $_POST["remember"];
    if(!isset($user) || empty($user)) {
        $user_error = "Please enter your email, username, or phone number";
        $user_error_hide = "";
    } else{$userText = $user;}
    if(!isset($password) || empty($password)) {
        $password_error = "Please enter your password";
        $password_error_hide = "";
    }
    if(strlen($user_error) == 0 && strlen($password_error) == 0) {
        $stmt = $session->db->getConnection()->prepare("SELECT password, email FROM users WHERE email = ? OR username = ? OR number = ? LIMIT 1");
        $user = trim($user);
        $stmt->bind_param("sss", $user, $user, $user);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($userPass, $email);
        $stmt->fetch();
        if($stmt->num_rows == 0) {
            $user_error = "No such user exists!";
            $user_error_hide = "";
        } else {
            require_once($_SERVER["DOCUMENT_ROOT"]. "/config/functions.php");
            $password = passwordHash($password);
            if($password != $userPass) {
                $password_error = "Incorrect password!";
                $password_error_hide = "";

            } else {
                $_SESSION["user"] = $user;
                if(isset($rememberMe)) {
                    $timeNow = time();
                    $userCookie = md5(randomName(12).strval($timeNow));
                    $timeNow += REMEMBER_ME_LIFE_SPAN_IN_SECONDS;
                    setcookie("user", $userCookie, $timeNow, "/", "", false, true);
                    require_once($_SERVER["DOCUMENT_ROOT"]. "/config/constants.php");
                    $stmt = $session->db->getConnection()->prepare("UPDATE users SET cookie = ?, cookie_exp = ? WHERE email = ?");
                    $stmt->bind_param('sis', $userCookie, $timeNow, $email);
                    $stmt->execute();
                }
                header("location: /dashboard");
            }
        }
        $stmt->close();
    }
}
$page = array();
$page['title'] = "Sign In";
$page['body'] = '
<div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h5 class="card-title text-center">Sign In</h5>
            <form method="POST" class="form-signin">
              <div class="form-label-group">
                <input name="user" value="'.$userText.'" type="text" id="inputEmail" class="form-control" placeholder="Email, Username, or Number" required autofocus>
                <label for="inputEmail">Email, Username, or Number</label>
                <div class="input_validation_error_text'.$user_error_hide.'">'.$user_error.'</div>
              </div>

              <div class="form-label-group">
                <input name="password" value="'.$passwordText.'" type="password" id="inputPassword" class="form-control" placeholder="Password" required>
                <label for="inputPassword">Password</label>
                <div class="input_validation_error_text'.$password_error_hide.'">'.$password_error.'</div>
              </div>

              <div class="custom-control custom-checkbox mb-3">
                <input name="remember" value="1" type="checkbox" class="custom-control-input" id="customCheck1" checked>
                <label class="custom-control-label" for="customCheck1">Remember me</label>
              </div>
              <button name="submit" value="submit" class="btn btn-lg btn-success btn-block text-uppercase" type="submit">Sign in</button>
              <hr class="hide my-4">
              <button class="hide btn btn-lg btn-google btn-block text-uppercase" type="submit"><i class="fab fa-google mr-2"></i> Sign in with Google</button>
              <button class="hide btn btn-lg btn-facebook btn-block text-uppercase" type="submit"><i class="fab fa-facebook-f mr-2"></i> Sign in with Facebook</button>
            </form>
          </div>
        </div>
      </div>
    </div>
';
return $page;
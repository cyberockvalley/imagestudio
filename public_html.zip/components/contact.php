<?php
if(isset($_POST['email'])) {
    require($_SERVER["DOCUMENT_ROOT"]. "/config/constants.php");
     
    // CHANGE THE TWO LINES BELOW
    $email_to = CONTACT_EMAIL;
     
    $email_subject = "website html form submissions";
     
     
    function died($error) {
        // your error code can go here
        echo "We are very sorry, but there were error(s) found with the form you submitted. ";
        echo "These errors appear below.<br /><br />";
        echo $error."<br /><br />";
        echo "Please go back and fix these errors.<br /><br />";
        die();
    }
     
    // validation expected data exists
    if(!isset($_POST['first_name']) ||
        !isset($_POST['last_name']) ||
        !isset($_POST['email']) ||
        !isset($_POST['telephone']) ||
        !isset($_POST['comments'])) {
        died('We are sorry, but there appears to be a problem with the form you submitted.');       
    }
     
    $first_name = $_POST['first_name']; // required
    $last_name = $_POST['last_name']; // required
    $email_from = $_POST['email']; // required
    $telephone = $_POST['telephone']; // not required
    $comments = $_POST['comments']; // required
     
    $error_message = "";
    $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
  if(!preg_match($email_exp,$email_from)) {
    $error_message .= 'The Email Address you entered does not appear to be valid.<br />';
  }
    $string_exp = "/^[A-Za-z .'-]+$/";
  if(!preg_match($string_exp,$first_name)) {
    $error_message .= 'The First Name you entered does not appear to be valid.<br />';
  }
  if(!preg_match($string_exp,$last_name)) {
    $error_message .= 'The Last Name you entered does not appear to be valid.<br />';
  }
  if(strlen($comments) < 2) {
    $error_message .= 'The Comments you entered do not appear to be valid.<br />';
  }
  if(strlen($error_message) > 0) {
    died($error_message);
  }
    $email_message = "Form details below.\n\n";
     
    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }
     
    $email_message .= "First Name: ".clean_string($first_name)."\n";
    $email_message .= "Last Name: ".clean_string($last_name)."\n";
    $email_message .= "Email: ".clean_string($email_from)."\n";
    $email_message .= "Telephone: ".clean_string($telephone)."\n";
    $email_message .= "Comments: ".clean_string($comments)."\n";
     
     
// create email headers
$headers = 'From: '.$email_from."\r\n".
'Reply-To: '.$email_from."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject, $email_message, $headers);  
?>
 
<!-- place your own success html below -->
 
Thank you for contacting us. We will be in touch with you very soon.
 
<?php
}
//die();
?>
<?php
$page = array();
$page['title'] = "Contact Us";
$page['body'] = '
<h1 style="padding-top:20px">Contact Us</h1>
<form style="max-width:600px;padding:10px;" method="POST" action="">
            <div class="form-group row">
              <label for="first_name" class="col-md-12" required="required">Firstname:</label>
              <div class="col-md-12">
                <input data-form="checkout" type="text" data-type="text" name="first_name" class="form-control" id="first_name" aria-describedby="first_name" placeholder="Enter your firstname">
              </div>
            </div>
            <div class="form-group row">
              <label for="last_name" class="col-md-12" required="required">Lastname:</label>
              <div class="col-md-12">
                <input data-form="checkout" type="text" data-type="text" name="last_name" class="form-control" id="last_name" aria-describedby="last_name" placeholder="Enter your lastname">
              </div>
            </div>
            <div class="form-group row">
              <label for="email" class="col-md-12" required="required">Email:</label>
              <div class="col-md-12">
                <input data-form="checkout" type="text" data-type="text" name="email" class="form-control" id="email" aria-describedby="email" placeholder="Enter your email">
              </div>
            </div>
            
            <div class="form-group row">
              <label for="number" class="col-md-12" required="required">Phone number:</label>
                <div class="col-md-12">
                  <input data-form="checkout" type="text" data-type="phone-number" name="telephone" class="form-control" id="telephone" aria-describedby="number" placeholder="Enter phone number">
              </div>
            </div>

            <div class="form-group row">
              <label for="comments" class="col-md-12" required="required">Message:</label>
              <div class="col-md-12">
                <textarea data-form="checkout" rows="4" style="resize:none;" data-type="text" name="comments" class="form-control" id="message" aria-describedby="message" placeholder="Enter your message here..."></textarea>
              </div>
            </div>
            <hr>
            <input type="submit" name="submit" id="submit" class="btn btn-success" value="Submit"/>
          </form>
';
return $page;
?>
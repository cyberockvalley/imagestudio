<?php
//https://www.xml-sitemaps.com/validate-xml-sitemap.html
class Gen {
    private $xml;
    private $isIndex;
    private static $searchEngines = array(
        array("http://search.yahooapis.com/SiteExplorerService/V1/updateNotification?appid=USERID&url=",
        "http://search.yahooapis.com/SiteExplorerService/V1/ping?sitemap="),
        "http://www.google.com/webmasters/tools/ping?sitemap=",
        "http://submissions.ask.com/ping?sitemap=",
        "http://www.bing.com/webmaster/ping.aspx?siteMap="
    );
    private $sitemapWrapper = '<?xml version="1.0" encoding="UTF-8"?>
                                <urlset 
                                    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                                    xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
                                    http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd"
                                    xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
                                </urlset>';
    private $sitemapIndexWrapper = '<?xml version="1.0" encoding="UTF-8"?>
                                    <sitemapindex
                                        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                                        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
                                        http://www.sitemaps.org/schemas/sitemap/0.9/siteindex.xsd"
                                        xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
                                    </sitemapindex>';

    public function __construct($isIndex) {
        $this->isIndex = $isIndex;
        if($isIndex) {
            $this->xml = new SimpleXMLElement($this->sitemapIndexWrapper);

        } else {
            $this->xml = new SimpleXMLElement($this->sitemapWrapper);
        }
    }

    public function addPage($page) {
        if($this->isIndex) {
            $row = $this->xml->addChild('sitemap');
            $row->addChild('loc', $page->url);
            if (isset($page->lastMod)) $row->addChild('lastmod', $page->lastMod);

        } else {
            $row = $this->xml->addChild('url');
            $row->addChild('loc', htmlspecialchars($page->url, ENT_QUOTES, 'UTF-8'));
            if (isset($page->lastMod)) $row->addChild('lastmod', $page->lastMod);
            if (isset($page->changeFreq)) $row->addChild('changefreq', $page->changeFreq);
            if (isset($page->priority)) $row->addChild('priority', $page->priority);
        }
    }
    
    public static function submitSitemap($mapLocation, $yahooAppId = null) {
        if (!extension_loaded('curl'))
            throw new BadMethodCallException("cURL library is needed to do submission.");
        $searchEngines = self::$searchEngines;
        $searchEngines[0] = isset($yahooAppId) ? str_replace("USERID", $yahooAppId, $searchEngines[0][0]) : $searchEngines[0][1];
        $result = array();
        for($i = 0; $i < sizeof($searchEngines); $i++) {
            $submitSite = curl_init($searchEngines[$i].htmlspecialchars($mapLocation, ENT_QUOTES, 'UTF-8'));
            curl_setopt($submitSite, CURLOPT_RETURNTRANSFER, true);
            $responseContent = curl_exec($submitSite);
            $response = curl_getinfo($submitSite);
            $submitSiteShort = array_reverse(explode(".", parse_url($searchEngines[$i], PHP_URL_HOST)));
            $result[] = array("site"=>$submitSiteShort[1].".".$submitSiteShort[0],
                "fullsite"=>$searchEngines[$i].htmlspecialchars($mapLocation, ENT_QUOTES,'UTF-8'),
                "http_code"=>$response['http_code'],
                "message"=>str_replace("\n", " ", strip_tags($responseContent)));
        }
        return $result;
    }
    public static function submitSitemaps($mapLocations, $yahooAppId = null) {
        foreach($mapLocations as $loc) {
            print_r(self::submitSitemap($loc, $yahooAppId));
        }
    }
    public function getXml() {
        return $this->xml->asXML();
    }
}
?>
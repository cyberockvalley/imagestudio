<?php
error_reporting(E_ALL ^E_NOTICE);
require_once($_SERVER['DOCUMENT_ROOT'] . "/config/functions.php"); 
require_once($_SERVER['DOCUMENT_ROOT'] . "/models/session.php");
require_once("Gen.php");
session_start();

$baseUrl = "https://dandavfarm.com";

 
$session = Session::getInstance();
$conn = $session->db->getConnection();

$lastActionTime = getLastActionTime();

$maxIndex = 1000;
$maxUrl = 50000;

$stmt = $conn->prepare("SELECT COUNT(id) FROM products WHERE last_update > ?");
$stmt->bind_param('i', $lastActionTime);
$stmt->execute();
$countResult = $stmt->get_result();
$countStmtRow = $countResult->fetch_row();
$count = $countStmtRow[0];

if($count > 0) {
    $totalSitemapIndex = ceil($count / ($maxIndex * $maxUrl));
    $indexUrls = array();
    for($i = 0; $i < $totalSitemapIndex; $i++) {
        $indexUrls[] = $baseUrl . '/sitemap.php?index='.strval($i + 1);
    }
    appendSitemapIndexUrlsToRobotFile($indexUrls);
    Gen::submitSitemaps($indexUrls);
}

function getLastActionTime() {
    $c = file_get_contents('last_action_time.txt');
    if(strlen($c) == 0) {
        return 0;

    } else {
        return intval(trim($c));
    }
}
function appendSitemapIndexUrlsToRobotFile($indexUrls) {
    global $baseUrl;
$indexList = 
"User-Agent: *
Disallow: /signin
Disallow: /dashboard

Sitemap: " . $baseUrl . "/sitemap.xml";
    foreach($indexUrls as $index) {
        $indexList .= "\nSitemap: " . $index;
    }
    file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/robots.txt', $indexList , LOCK_EX);
    file_put_contents('last_action_time.txt', strval(time()) , LOCK_EX);
}
echo "<p>LastActionTime: $lastActionTime</p><p>LastActionDate: ".date('c', $lastActionTime)."</p>";
?>
<?php
class Page {
    public $url;
    public $lastMod;
    public $changeFreq;
    public $priority;
}
?>
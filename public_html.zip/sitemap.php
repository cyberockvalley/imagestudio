<?php
error_reporting(E_ALL ^E_NOTICE);
if (substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzindex')) {
    ob_start('ob_gzhandler'); 
} else {
    ob_start();
}
session_start();
require_once("config/functions.php"); 
require_once("models/session.php");
require_once("sitemap/Gen.php");
require_once("sitemap/Page.php");

$baseUrl = "https://dandavfarm.com";

$session = Session::getInstance();
$conn = $session->db->getConnection();

$maxIndex = 1000;
$maxUrl = 50000;
function intSet($var) {
    return isset($var) && ((int)$var) > 0;
}
$indexPage = intSet($_GET["index"])? $_GET["index"] : 1;
$mapPage = intSet($_GET["map"])? $_GET["map"] : 0;
$siteMapLinks = array();
if($mapPage == 0) {
    $generator = new Gen(true);
    $offest = ($indexPage - 1) * $maxIndex;
    $countStmt = $conn->prepare("SELECT COUNT(id) FROM products LIMIT $offest, $maxIndex");
    $countStmt->execute();
    $countResult = $countStmt->get_result();
    $countStmtRow = $countResult->fetch_row();
    $count = $countStmtRow[0];
    $totalIndex = ceil($count / $maxIndex);

    for($i = 0; $i < $totalIndex; $i++) {
        $page = new Page();
        $page->url = $baseUrl . "/sitemap.php?index=" . strval($indexPage) . "&amp;map=" . strval($i + 1);
        //$page->lastMod = date('c');
        $generator->addPage($page);
    }
    $xml = $generator->getXml();

} else {
    $generator = new Gen(false);
    $offestSitemapIndex = ($indexPage - 1) * $maxIndex;
    $offest = $offestSitemapIndex * $maxUrl;
    $stmt = $conn->prepare("SELECT id, title, last_update FROM products ORDER BY id DESC LIMIT $offest, $maxUrl");
    $stmt->execute();
    $result = $stmt->get_result();
    while($row = $result->fetch_object()) {
        $page = new Page();
        $page->url = $baseUrl . productLink($row->title, $row->id);
        $page->lastMod = date('c', $row->last_update);
        $page->priority = "1.0";
        $generator->addPage($page);
    }
    $xml = $generator->getXml();
}

header("Content-Type: application/xml");
echo $xml;
?>
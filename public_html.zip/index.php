<?php
//ini_set('display_errors', 1);
  if(isset($_POST["signout"])) {
    session_start();
    setcookie('user', "out", time() - 86400, "/");
    session_unset();
    session_destroy();
  } else {
    session_start();
  }
  error_reporting(E_ALL ^E_NOTICE);
  require_once("config/functions.php"); 
?>
<?php 
      require_once($_SERVER["DOCUMENT_ROOT"]. "/models/session.php");
      $session = Session::getInstance();
      $page = get_page($session);
?>
<!doctype html>
<html lang="en">
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <!-- Required meta tags -->
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="theme-color" content="#007b5e">

    
    <meta datafixed="1" name="application-name" content="<?=HOST;?>">
    <meta datafixed="0" name="description" content="<?= SITE_TRADE_MARK." ".$page["meta-description"]." | ".SITE_NAME; ?>">
    <meta datafixed="0" name="keywords" content="<?= $page["meta-keywords"]; ?>">
    <meta datafixed="0" property="og:title" content="<?= $page["title"]; ?>">
    <meta datafixed="0" property="og:url" content="<?= $page["meta-url"]; ?>">
    <meta datafixed="0" property="og:description" content="<?= $page["og-description"]; ?>">
    <meta datafixed="0" property="og:image:type" content="<?= $page["og-image-type"]; ?>">
    <meta datafixed="0" property="og:image" content="<?= $page["og-image"]; ?>">
    <title><?= $page["title"]; ?></title>
    <link rel="icon" href="/res/favicon.ico" type="image/x-icon" />
    <link datafixed="0" rel="canonical" content="<?= $page["meta-url"]; ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!--font-->
    <link href="https://fonts.googleapis.com/css?family=Ubuntu:400,700&amp;subset=latin-ext" rel="stylesheet" type='text/css'>
    <link rel="stylesheet" href="/res/font-awesome/css/font-awesome.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="/res/css/styles.css" />
  </head>
  <body>
    <div id="page-container">
      <?php $bodyAlone = isset($page['body-alone']) && $page['body-alone'];  if(!$bodyAlone)get_header($session); //echo "Password: ".md5("111111".SALT); ?>
      <?php 
      if(!$bodyAlone) {
        $cart = require_once($_SERVER["DOCUMENT_ROOT"]. "/components/cart.php");
      ?>
      <div id="content-wrap" class="container">
        <!-- all other page content -->
        <?= $page["body"]; ?>
      </div>
      <?php echo $cart; } else {echo $page["body"];}?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <?php if(!$bodyAlone)get_footer(); ?>
    </div>
    <script>
      const CART = "cart";
      const LOCAL_STORAGE = window.localStorage;
      var cartItems = [];
      var cartItemsIds = [];
      $(document).ready(function(){
        initStorage();
        updateCartCounter();
        $("input[data-type='number']").keyup(function(event){
          // skip for arrow keys
          if(event.which >= 37 && event.which <= 40){
            event.preventDefault();
          }
          var $this = $(this);
          var num = $this.val();
          var num2 = commaNum(num);
          console.log(num2);
          $this.val(num2);
        });
        $.each($('span[data-type="number"]'), function(item, index) {
          $(this).html(commaNum($(this).html()));
        });
        $("[data-call]").click(function(e) {
          const $this = $(this);
          const number = $this.attr("data-call");
          const callClass = $this.attr("data-call-class");
          $this.html(formatPhoneNumber(number)+' <i class="'+callClass+'"></i>');
          call(number);
        });
      });
      const commaNum = (num) => {
        num += "";
        console.log("NUM BEFORE", num);
        //remove non-digit characters
        num = num.replace(/\D/g, "");
        //add commas before every 3 digits
        num = num.split(/(?=(?:\d{3})+$)/).join(",");
        return num;
      }
      const formatPhoneNumber = (num) => {
        num += "";
        var plus = "";
        if(num.startsWith("+"))plus = "+"; num = num.substr(1);
        //remove non-digit characters
        num = num.replace(/\D/g, "");
        //add commas before every 3 digits
        // /(?=(?:\d{3})+$)/
        // (?:\(\d{3}\)|\d{3})[- ]?\d{3}[- ]?\d{4}
        num = num.split(/(?=(?:\d{3})+(?:\d{4})$)/).join("-");
        num = num.split(/(?=(?:\d{4})+$)/).join("-");
        return plus+num;
      }
      const truncText = (text, len, append) => {
        text += "";
        if(text.length <= len) {
          return text;

        } else {
          return text.substr(0, len)+(append?append:"");
        }
      }
      const initStorage = () => {
        if(LOCAL_STORAGE.getItem(CART) == null)LOCAL_STORAGE.setItem(CART, "");
        refactorCart();
        if(countCartItems() > 0) {
          $.ajax({
            url: "/api/v1/products/get.php?id="+LOCAL_STORAGE.getItem(CART),
            type: "GET",
            cache: false,
            processData: false,
            contentType: false,
            success: function(data, textStatus, jqXHR) {
              console.log("Data: " + data + "\nStatus: " + status);
              var result = data;//JSON.parse(data);
              console.log("result", result);
              if(result && result.list && result.list.length > 0) {
                const cart = LOCAL_STORAGE.getItem(CART);
                for(const item of result.list) {
                  cartItemsIds.push(item.id);
                  cartItems.push(item);
                }
                console.log("LIST", result.list);
                console.log("LIST_CART", cartItems);
                updateCartItems();
                var cartIds = cart.substr(0, cart.length - 1).split(",");
                for(const cartId of cartIds) {
                  if(!cartItemsIds.includes(parseInt(cartId))) {
                    removeFromCart({id: cartId});
                  }
                }
                updateCartCounter();  
              }
            },
            error: function (jqXHR, textStatus, errorThrown) {
              console.log("error: " + errorThrown + "\nStatus: " + textStatus);
            }
          });
        }
      }
      const updateCartItems = () => {
        $("#cart-items-container").html("");
        var totalPrice = 0;
        cartItems.forEach((item, index) => {
          totalPrice += item.price;
          $("#cart-items-container").append(`
                    <!-- PRODUCT -->
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-2 text-center">
                                <img class="img-responsive" src="`+item.photos.split(',')[0]+`" alt="prewiew" width="120" height="80">
                        </div>
                        <div class="col-12 text-sm-center col-sm-12 text-md-left col-md-6">
                            <h4 class="product-name"><strong>`+item.title+`</strong></h4>
                            <h4>
                                <small>`+truncText(item.description, 70, "...")+`</small>
                            </h4>
                        </div>
                        <div class="col-12 col-sm-12 text-sm-center col-md-4 text-md-right row">
                            <div class="col-3 col-sm-3 col-md-6 text-md-right" style="padding-top: 5px">
                                <h6><strong>&#8358; `+commaNum(item.price)+` <span class="text-muted hide">x</span></strong></h6>
                            </div>
                            <div class="col-4 col-sm-4 col-md-4 hide">
                                <div class="quantity">
                                    <input type="button" value="+" class="plus">
                                    <input type="number" step="1" max="99" min="1" value="1" title="Qty" class="qty"
                                           size="4">
                                    <input type="button" value="-" class="minus">
                                </div>
                            </div>
                            <div class="col-2 col-sm-2 col-md-2 text-right">
                                <button onClick="removeFromCart({id: `+item.id+`})" type="button" class="btn btn-outline-danger btn-xs">
                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <!-- END PRODUCT -->
                    `);
        });
        $("#total-price").html("&#8358; "+commaNum(totalPrice));
        refactorCart();
      }
      const checkOut = () => {
        document.location.href = "/checkout";
      }
      const refactorCart = () => {
        if(cartItems.length == 0) {
          $.each($("[data-cart-hide-on-empty]"), function(item, index) {
            if($(this).attr("data-cart-hide-on-empty") == "true") {
              $(this).addClass("hide");

            } else {
              $(this).removeClass("hide");
            }
          });

        } else {
          $.each($("[data-cart-hide-on-empty]"), function(item, index) {
            if($(this).attr("data-cart-hide-on-empty") == "true") {
              $(this).removeClass("hide");

            } else {
              $(this).addClass("hide");
            }
          });
        }
      }
      const productLink = (title, id) => {
        title = title.trim();
        title = title.replace(/[\s\.]+/g, "-");
        title = title.replace(/[^-\dA-Z-a-z]/g, "");
        if(title.startsWith("-"))title = title.substring(1);
        if(title.endsWith("-"))title = title.substring(0, title.length -1);
        return ("/products/"+title+"/"+id).toLowerCase();
      }
      const isInCart = (id) => {
        var cart = LOCAL_STORAGE.getItem(CART);
        log(["CART", cart]);
        return cart.includes(id+",");
      }
      const addToCart = (item) => {
        if(!isInCart(item.id)){
          LOCAL_STORAGE.setItem(CART, LOCAL_STORAGE.getItem(CART)+item.id+",");
          var index = cartItems.findIndex(function(cartItem) {
            return cartItem.id == item.id;
          });
          if(index == -1) {
            try {
              cartItems.push(item);
              cartItemsIds.push(item.id);
              updateCartItems();

            }catch(e){}
          }
          updateCartCounter();
          try{
            updateCartState(isInCart(productId));
          } catch(e){}
        }
        log(["CART", "beforeAdd", LOCAL_STORAGE.getItem(CART)]);
        log(["CART", "add", item.id, LOCAL_STORAGE.getItem(CART)]);
      }
      const removeFromCart = (item) => {
        const regex = new RegExp(item.id+",");
        LOCAL_STORAGE.setItem(CART, LOCAL_STORAGE.getItem(CART).replace(regex, ""));
        
        var index = cartItems.findIndex(function(cartItem) {
            return cartItem.id == item.id;
        });
        if(index > -1) {
            try {
            cartItems.splice(index, 1);
            cartItemsIds.splice(index, 1);
            updateCartItems();

            }catch(e){}
        }
        updateCartCounter();
        try{
          updateCartState(isInCart(productId));
        } catch(e){}
        log(["CART", "beforeRemove", LOCAL_STORAGE.getItem(CART)]);
        log(["CART", "remove", item.id, LOCAL_STORAGE.getItem(CART)]);
      }
      const countCartItems = () => {
        var cart = LOCAL_STORAGE.getItem(CART);
        if(cart.includes(","))cart = cart.substr(0, cart.length - 1);
        cart = cart.split(",");
        return cart == ""?0:cart.length;
      }
      const clearCart = () => {
        LOCAL_STORAGE.setItem(CART, "");
        cartItemsIds = [];
        cartItems = [];
        try{
            updateCartState(isInCart(productId));
        } catch(e){}
        updateCartCounter();
        updateCartItems();
      }
      const updateCartCounter = () => {
        const totalCartItems = countCartItems();
        $.each($('[data-cart-count]'), function() {
          $(this).attr('data-cart-count', totalCartItems);
        });
      }
      const showCart = () => {
        $('#content-wrap').hide();
        $('#cart').show();
      }
      const hideCart = () => {
        $('#content-wrap').show();
        $('#cart').hide();
      }
      const toggleCart = () => {
        $('#content-wrap').toggle();
        $('#cart').toggle();
      }
      const log = (array) => {
        var msgs = "";
        for(const msg of array) {
          msgs += msg + " ";
        }
        console.log(msgs);
      }

      const modalAlert = (msg, func) => {
        alert(msg);
      }

      const setError = (idName, error) => {
        $("#"+idName+"-error").attr("data-error", error);
      }
      const clearErrors = () => {
        $(".error").each(function(i, el){
          $(el).attr("data-error", "");
        });
      }
      const call = (number) => {
        window.location = "tel:"+number;
      }
    </script>
    <?=$page["script"]?>
  </body>
</html>
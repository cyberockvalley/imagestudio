<?php
session_start();
require_once($_SERVER["DOCUMENT_ROOT"]. "/models/session.php");
$session = Session::getInstance(); 
$status = 200;
$response = array();
define("ONLY_ADMIN_CAN_ADD_CAT", true);

if($session->user == null) {
    $response["auth_required"] = true;
    $response["error"] = "Please sign in first";

} else if($session->user->rank < 1 && ONLY_ADMIN_CAN_ADD_CAT) {
    $response["error"] = "Only an admin can add a category";

} else {
    $body = json_decode($_POST["body"]);
    $errors = array();
    if(!isset($body) || empty($body)) {
        $response["error"] = "No data received";

    } else {
        $name = $body->category_name;
        $description = $body->category_description;
        if(!isset($name) || empty($name) || empty(trim($name))) {
            $errors["category_name_error"] = "Please enter category name";

        } else {
            $name = trim($name);
        }

        if(!isset($description) || empty($description) || empty(trim($description))) {
            $errors["category_description_error"] = "Please enter category description";

        } else {
            $description = trim($description);
        }

        if(count($errors) > 0) {
            $response["errors"] = $errors;

        } else {
            $conn = $session->db->getConnection();
            $stmt = $conn->prepare("INSERT INTO cats(name, description, created) VALUES(?, ?, ?)");
            $now = time();
            $stmt->bind_param('ssi', $name, $description, $now);
            if($stmt->execute()) {
                $response["success"] = true;

            } else {
                $status = 503;
                $response["error"] = "An error occured from the server";
            }
        }
    }
}

header("Content-type: application/json");
http_response_code($status);
echo json_encode($response);
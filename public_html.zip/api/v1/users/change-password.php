<?php
session_start();
require_once($_SERVER["DOCUMENT_ROOT"]. "/models/session.php");
$session = Session::getInstance(); 
$status = 200;
$response = array();
if($session->user == null) {
    $response["auth_required"] = true;
    $response["error"] = "Please sign in first";

} else {
    $body = json_decode($_POST["body"]);
    $password = $body->password;
    $newPassword = $body->new_password;
    $errors = array();
    if(!isset($password) || empty($password)) {
        $errors["password-error"] = "Please enter your password";
    }
    if(!isset($newPassword) || empty($newPassword)) {
        $errors["new_password-error"] = "Please enter your new password";
    }
    if(count($errors) == 0) {
        $conn = $session->db->getConnection();
        $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param('i', $session->user->id);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($dbPass);
        $stmt->fetch();
        require_once($_SERVER["DOCUMENT_ROOT"]. "/config/functions.php");
        if(passwordHash(trim($password)) != $dbPass) {
            $errors["password-error"] = "Incorrect password!";


        } else {
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $newPassword = passwordHash($newPassword);
            $stmt->bind_param('si', $newPassword, $session->user->id);
            if($stmt->execute()) {
                $response["success"] = true;

            } else {
                $response["error"] = "An unexpected error occured from the server";
                $status = 503;
            }
        }
    }
    $stmt->close();
    $response["errors"] = $errors;

}

header("Content-Type: application/json");
http_response_code($status);
echo json_encode($response);
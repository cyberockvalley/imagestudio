<?php
session_start();
error_reporting(E_ALL ^E_NOTICE);
require_once($_SERVER["DOCUMENT_ROOT"]. "/config/functions.php");
require_once($_SERVER["DOCUMENT_ROOT"]. "/models/session.php");
$session = Session::getInstance();
$data = $_POST["data"];
$productIds = $_POST["product_ids"];
$captcha = $_POST["captcha"];

$status = 200;
$response = array();
$errors = array();
if(!isset($captcha) || empty($captcha)) {
    $response["error"] = "No captcha provided";

} else if(!isValidCaptcha($captcha)) {
    $response["error"] = "Invalid captcha";

} else if(!isset($data)) {
    $response["error"] = "No data provided";

} else {
    $data = json_decode($data);
    $email = $data->email;
    $number = $data->number;
    $message = $data->message;
    if(!isset($productIds) || empty($productIds)) {
        $productIds = "";

    } else {
        $productIds = preg_grep("~^\d+$~", preg_split("~,~", $productIds));
        if(count($productIds) > 0) {
            $productIds = join(",", $productIds);
        }
    }

    if(!isset($message) || empty($message)) {
        $message = "";

    } else if(strlen($message) > 200) {
        $errors["message-error"] = "Your message is too long";

    }

    if(!isset($email) || empty($email)) {
        $errors["email-error"] = "Please enter your email address";

    } else if(!isValidEmail($email)) {
        $errors["email-error"] = "Please enter a valid email address";

    }

    if(!isset($number) || empty($number)) {
        $errors["number-error"] = "Please enter your phine number";

    } else if(!isValidPhoneNumber($number)) {
        $errors["number-error"] = "Please enter a valid phone number";

    }

    if(count($errors) == 0) {
        $conn = $session->db->getConnection();
        $stmt = $conn->prepare("INSERT INTO orders(user_id, product_ids, email, number, message, created) VALUES(?, ?, ?, ?, ?, ?)");
        $userId = 1;
        $now = time();
        $stmt->bind_param("issssi", $userId, $productIds, $email, $number, $message, $now);
        if($stmt->execute()) {
            $response["success"] = true;

        } else {
            $response["error"] = "An error occured from the server".$stmt->error;
            $status = 503;
        }
    }
}
$response["errors"] = $errors;

header("Content-Type: application/json");
http_response_code($status);
echo json_encode($response);
?>
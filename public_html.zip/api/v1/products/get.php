<?php
session_start();
error_reporting(E_ALL ^E_NOTICE);
require_once($_SERVER["DOCUMENT_ROOT"]. "/config/constants.php");
require_once($_SERVER["DOCUMENT_ROOT"]. "/config/functions.php");
require_once($_SERVER["DOCUMENT_ROOT"]. "/models/session.php");
require_once($_SERVER["DOCUMENT_ROOT"]. "/models/product.php");
$status = STATUS_OK;
$response = array("error" => null, "list" => []);
$id = $_GET["id"];
$result = null;
$st = "SELECT products.*, cats.name as cat_name FROM products, cats";
$paramKeys = "";
$paramValues = "";
$conn = Session::getInstance()->db->getConnection();
if(isset($id) && !empty($id)) {
    if(endsWith($id, ","))$id = substr($id, 0, strlen($id) - 1);
    $ids = preg_grep("~^\d+$~", preg_split("~,~", $id));
    
    if(count($ids) > 0) {
        $i = 0;
        foreach($ids as $value) {
            $st .= orQuery("products.id = $value", $st);
            $st .= andQuery("cats.id = products.cat_id", $st);
            $i++;
            if($i == PRODUCTS_PER_PAGE)break;
        }
        //echo $st;
        $stmt = $conn->prepare($st);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
    }
}
if($result != null && $result->num_rows > 0) {
    $list = array();
    while($row = $result->fetch_object()) {
        $product = new Product();
        $product->fillFromObject($row);
        array_push($list, (array)$product);
        //print_r($product);
        //print_r((array)$product);
    }
    $response["list"] = $list;
}

header("Content-Type: application/json");
http_response_code($status);
echo json_encode($response);
?>
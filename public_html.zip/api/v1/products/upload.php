<?php
    session_start();
    error_reporting(E_ALL ^E_NOTICE);
    require_once($_SERVER["DOCUMENT_ROOT"]. "/config/constants.php");
    require_once($_SERVER["DOCUMENT_ROOT"]. "/config/functions.php");
    require_once($_SERVER["DOCUMENT_ROOT"]. "/models/session.php");
    require_once($_SERVER["DOCUMENT_ROOT"]. "/models/product.php");

    $status = STATUS_OK;
    $response = array();
    $session = Session::getInstance();
    $photos = $_FILES["photo"];

    if($session->user == null) {
        $response["auth_required"] = true;
        $response["error"] = "Please sign in first";

    } else if(!isset($_POST["body"]) || empty($_POST["body"])) {
        $response["error"] = "No data received";

    } else {
        $body = json_decode($_POST["body"]);
        $errors = array();

        $title = $body->title;
        $description = $body->description;
        $category = $body->category;
        $price = $body->price;
        $scale = $body->scale;
        $nego = $body->nego;
        if(!$title) {
            $errors["title-error"] = "Please enter a title";

        } else if(strlen($title) < 5) {
            $errors["title-error"] = "The title is too short";

        } else {
            $title = trim($title);
        }

        if(!$description) {
            $errors["description-error"] = "Please enter a description";

        } else if(strlen($description) < 5) {
            $errors["description-error"] = "The description is too short";
            
        } else {
            $description = trim($description);
        }

        if(!$category) {
            $errors["category-error"] = "Please select a category";

        } else {
            $catExists = false;
            $cats = $session->db->get_cats()['list'];
            $cat_name = "";
            foreach($cats as $struct) {
                if (trim(intval($category)) == $struct->id) {
                    $catExists = true;
                    $cat_name = $struct->name;
                    break;
                }
            }
            if(!$catExists) {
                $errors["category-error"] = "Unrecognised category";

            } else {
                $category = trim(intval($category));
            }
        }


        if(!$price || intval(trim(str_replace(",", "", $price))) == 0) {
            $errors["price-error"] = "Please enter a price";

        } else {
            $price = intval(trim(str_replace(",", "", $price)));
        }

        if(!$scale) {
            $errors["scale-error"] = "Please select a scale";

        } else {
            $scale = trim($scale);
        }

        //echo print_r($photos);
        if(!$photos) {
            $errors["product_photos-error"] = "Please add at least a photo to your product";

        } else if(in_array(1, $photos["error"])) {
            $errors["product_photos-error"] = "There is an error with your photo";

        }

        if(count($errors) > 0) {
            $response["errors"] = $errors;

        } else {
            $totalMaxSize = MAX_TOTAL_IMAGE_SIZE_IN_MB * 1024 * 1024;
            $acceptedMimes = array("image/jpeg", "image/jpg", "image/png");
            $uploadResult = uploadFiles($photos, "/res/images/products/", $totalMaxSize, $acceptedMimes);
            if(count($uploadResult["uploaded"]) == 0) {
                $response["error"] = $uploadResult["errors"][0];

            } else {
                $conn = $session->db->getConnection();
                $stmt = $conn->prepare("INSERT INTO products(user_id, title, description, cat_id, photos, price, scale, negotiable, created, last_update) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $now = time();
                $photosLinks = join(",", $uploadResult["uploaded"]);
                $nego = isset($_POST["nego"])?1:0;
                $stmt->bind_param("issisisiii", $session->user->id, $title, $description, $category, $photosLinks, $price, $scale, $nego, $now, $now);
                if($stmt->execute()) {
                    $response["success"] = 1;
                    $stmt = $conn->prepare("SELECT id FROM products WHERE photos = ?");
                    $stmt->bind_param("s", $photosLinks);
                    $stmt->execute();
                    $stmt->bind_result($id);
                    $stmt->store_result();
                    $stmt->fetch();
                    $product = new Product();
                    $product->id = $id;
                    $product->user_id = $session->user->id;
                    $product->title = $title;
                    $product->description = $description;
                    $product->cat_id = $category;
                    $product->cat_name = $cat_name;
                    $product->price = $price;
                    $product->scale = $scale;
                    $product->negotiable = $nego == 1;
                    $product->photos = $photosLinks;
                    $product->created = $now;
                    $product->last_update = $now;
                    $response["product"] = $product;

                } else {
                    $response["error"] = "An error occured from the server.";
                }
                $stmt->close();
            }

        }

    }
    

    header("Content-Type: application/json");
    http_response_code($status);
    echo json_encode($response);
?>
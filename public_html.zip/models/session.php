<?php
require_once($_SERVER["DOCUMENT_ROOT"]. "/models/user.php");
require_once($_SERVER["DOCUMENT_ROOT"]. "/config/db.php");

class Session {
    // Hold the class instance.
    private static $instance = null;
    var $user;
    var $db;

    private function __construct() {
        $this->db = new Database();
        $user = $_SESSION['user'];
        $userCookie = $_COOKIE['user'];

        if(isset($user) || isset($userCookie)){
            $stmt = $this->db->getConnection()->prepare("SELECT id, cookie, cookie_exp, email, username, number, profile_photo, rank FROM users WHERE email = ? OR username = ? OR number = ? OR cookie = ? LIMIT ?");
            $lim = 1;
            $stmt->bind_param('ssssi', $user, $user, $user, $userCookie, $lim);
            $stmt->execute();
            $stmt->store_result();
 
            // get variables from result.
            $stmt->bind_result($id, $cookie, $cookie_exp, $email, $username, $number, $profile_photo, $rank);
            $stmt->fetch();
            if($stmt->num_rows > 0){
                $timeNow = time();
                if($user == $email || $user == $username || $user == $number || ($userCookie == $cookie && $cookie_exp > $timeNow)) {
                    if(!isset($user))$_SESSION['user'] = $email;
                    $this->user = new User();
                    $this->user->id = $id;
                    $this->user->email = $email;
                    $this->user->username = $username;
                    $this->user->number = $number;
                    $this->user->profile_photo = $profile_photo;
                    $this->user->rank = $rank;
                }
            }
            $stmt->close();
        }
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new Session();
        }
 
        return self::$instance;
    }
}
?>
<?php
class User {
    var $name;
}
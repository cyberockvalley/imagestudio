<?php
class Product {
    var $id;
    var $user_id;
    var $cat_id;
    var $cat_name;
    var $title;
    var $description;
    var $photos;
    var $price;
    var $scale;
    var $negotiable;
    var $created;
    var $last_update;

    public function __construct() {

    }
    public static function withIDs( $idArray ) {
        $instance = new self();
        $instance->loadByIDs( $idArray );
        return $instance;
    }
    public static function withID( $id ) {
        $instance = new self();
        $instance->loadByID( $id );
        return $instance;
    }
    protected function loadByID( $id ) {
        $stmt = Session::getInstance()->db->getConnection()->prepare("SELECT products.*, cats.name as cat_name FROM products, cats WHERE products.id = ? AND cats.id = products.cat_id");
        echo $stmt->err;
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $object = $result->fetch_object();
        $this->fillFromObject($object);
    }

    public function fillFromObject($object) {
        // Initializing class properties 
        foreach($object as $property => $value) { 
            if(property_exists($this, $property)) {
                $this->$property = $value;
            }
        } 
    }

}
?>
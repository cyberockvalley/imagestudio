<?php
class Cat {
   var $id; 
   var $name;
   var $description;
}
?>
<?php require_once(__DIR__ . "/config/constants.php");?>
<?php require_once(__DIR__ . "/config/functions.php");?>

<nav id="header" class="navbar navbar-expand-lg navbar-light bg-site">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggler" aria-controls="navbarToggler" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="/"><?=SITE_NAME;?></a>
  <i class="fa fa-shopping-cart fa-2x md-hide-up" data-cart-count="0" onClick="showCartItems()"></i>
  <div id="navbarToggler" class="collapse navbar-collapse">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <?php
        if($session->user) {
      ?>
            <li class="nav-item">
              <a href="/dashboard" class="nav-link">Dashboard</a>
            </li>
      <?php
        }
      ?>
      <?php
        if($session->user) {
      ?>
          <li class="nav-item">
            <form id="logout-form" style="display:inline !Important" method="POST" action="/signin">
              <input style="display:inline !Important" type="hidden" name="signout" value="1"/>
              <a onClick="document.getElementById('logout-form').submit()" href="javascript:void(0)" class="nav-link">Sign out</a>
            </form>
          </li>
      <?php
        } else {
      ?>
          <li class="nav-item">
            <a href="/signin" class="nav-link">Sign in</a>
          </li>
      <?php
        }
      ?>
    </ul>
    <form id="search-filter" method="GET" action="/" class="form-inline my-2 my-lg-0">
      <?php 
        $page = $_GET["pg"];
        $cats = $session->db->get_cats(); 
        $catId = $_GET["cat_id"];
        $search = $_GET["search"];
        if($cats != null && $cats["list"] != null) {
      ?>
      <input type="hidden" name="pg" value="<?=$page?>"/>
      <select name="cat_id" onChange="document.getElementById('search-filter').submit()" class="form-control mr-sm-2 mt-2" aria-label="Search">
        <option value="-1">--Select category--</option>
        <?php
          foreach($cats["list"] as $cat) {
            if($catId == $cat->id) {
              echo '<option value="'.$cat->id.'" selected>'.$cat->name.'</option>';

            } else {
              echo '<option value="'.$cat->id.'">'.$cat->name.'</option>';
            }
          }
        ?>
      </select>
  <?php } ?>
      <input name="search" value="<?=fakeHtml($search);?>" class="form-control mr-sm-2 mt-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success mr-sm-2 mt-2" type="submit">Search</button>

      
    </form>
    <div class="mr-sm-2 mt-2">
      <i onClick="toggleCart()" class="fa fa-shopping-cart fa-2x sm-hide-down" data-cart-count="0"></i>
    </div>
  </div>
</nav>
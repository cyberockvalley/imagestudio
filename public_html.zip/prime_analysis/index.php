<?php include_once("functions.php");
define("DEFAULT_LIMIT", 1000);
$limit = isset($_GET["limit"]) && ((int)$_GET["limit"]) > 0?((int)$_GET["limit"]):DEFAULT_LIMIT;
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Test Page</title>
        <style>
            *{box-sizing: border-box;}
            .row:after{clear: both}
            .spilt{float:left;width:50%}
            :not(table).spilt{padding:15px}
        </style>
    </head>
    <body>
        <div class="row">
            <table border="1" class="spilt">
                <tr>
                    <th>Prime 1</th>
                    <th>Prime 3</th>
                    <th>Prime 7</th>
                    <th>Prime 9</th>
                </tr>
                <tbody>
                    <?php
                    $primeCount = 0; $compositeCount = 0;
                    $rows = 1; $numbers = 0;
                    $totalByColumn = array();
                    $totalByColumn[0] = 0;
                    $totalByColumn[1] = 0;
                    $totalByColumn[2] = 0;
                    $totalByColumn[3] = 0;
                    for($i = 0; $i < $limit; $i+=10) {
                    ?>
                        <tr>
                            <?php 
                                $isPrime = isPrime($i + 1); 
                                if($isPrime){
                                    $primeCount++;
                                    $totalByColumn[0] += 1;
                                }else{
                                    $compositeCount++;
                                }
                                $numbers++;
                            ?>
                            <td style="background:<?=$isPrime?"#0f0":"#f00"?>">
                                <?=$i + 1?>
                            </td>
                            <?php 
                                $isPrime = isPrime($i + 3); 
                                if($isPrime){
                                    $primeCount++;
                                    $totalByColumn[1] += 1;
                                }else{
                                    $compositeCount++;
                                } 
                                $numbers++;
                            ?>
                            <td style="background:<?=$isPrime?"#0f0":"#f00"?>">
                                <?=$i + 3?>
                            </td>
                            <?php 
                                $isPrime = isPrime($i + 7); 
                                if($isPrime){
                                    $primeCount++;
                                    $totalByColumn[2] += 1;
                                }else{
                                    $compositeCount++;
                                }
                                $numbers++; 
                            ?>
                            <td style="background:<?=$isPrime?"#0f0":"#f00"?>">
                                <?=$i + 7?>
                            </td>
                            <?php 
                                $isPrime = isPrime($i + 9); 
                                if($isPrime){
                                    $primeCount++;
                                    $totalByColumn[3] += 1;
                                }else{
                                    $compositeCount++;
                                }
                                $numbers++;
                                $rows++; 
                            ?>
                            <td style="background:<?=$isPrime?"#0f0":"#f00"?>">
                                <?=$i + 9?>
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
            <div class="spilt">
                <p>Total Numbers: <?=$numbers?></p>
                <p>Total Rows: <?=$rows?></p>
                <p>Max number: <?=($i - 10) + 9?></p>
                <p>Total Primes: <?=$primeCount?></p>
                <p>Total Composites: <?=$compositeCount?></p>
                <p>Difference: <?=$compositeCount - $primeCount?></p>
                <p>Prime 1 total: <?=$totalByColumn[0]?></p>
                <p>Prime 3 total: <?=$totalByColumn[1]?></p>
                <p>Prime 7 total: <?=$totalByColumn[2]?></p>
                <p>Prime 9 total: <?=$totalByColumn[3]?></p>
            </div>
        </div>
    </body>
</html>
<?php
define("HOST", "dandavfarm.com");
define("HOST_ADDR", "https://".HOST);
define("USER", "jobabroa_dandav");
define("PASSWORD", "b(2s;Vj*{j@3#dDLc");
define("DATABASE", "jobabroa_dandavfarm");
define("SITE_NAME", "Dandavfarm");
define("SITE_TRADE_MARK", "Dandavfarm.com™");
define("SITE_FULL_NAME", "Dav&Dan Goshen Livestock Farms(dandavfarm)");
define("COMPANY_TYPE", "");
define("CEO", "Olufunmilayo Adeleke");
define("COMPANY_ADDRESS", "Km 7, Zone 10, Celica, Ibadan, Nigeria.");

define("TWITTER_USER", "dandavfarm");
define("CONTACT_EMAIL", "dandavfarm@gmail.com");
define("CONTACT_NUMBER", "+2348039501200");

define("FB_PAGE", "http://facebook.com/dandavfarm");
define("TWITTER_PAGE", "http://twitter.com/".TWITTER_USER);
define("INSTA_PAGE", "http://instagram.com/dandavfarm5");

$PAGES_COMPONENTS = array(
    "~^/?$~" => $_SERVER["DOCUMENT_ROOT"]. "/components/home.php",
    "~^/?products(/.*|\?.*|#.*)?$~" => $_SERVER["DOCUMENT_ROOT"]. "/components/product.php",
    "~^/?signin(/.*|\?.*|#.*)?$~" => $_SERVER["DOCUMENT_ROOT"]. "/components/login.php",
    "~^/?dashboard(/.*|\?.*|#.*)?$~" => $_SERVER["DOCUMENT_ROOT"]. "/components/dashboard.php",
    "~^/?checkout(/.*|\?.*|#.*)?$~" => $_SERVER["DOCUMENT_ROOT"]. "/components/checkout.php",
    "~^/?about(/.*|\?.*|#.*)?$~" => $_SERVER["DOCUMENT_ROOT"]. "/components/about.php",
    "~^/?contact-us(/.*|\?.*|#.*)?$~" => $_SERVER["DOCUMENT_ROOT"]. "/components/contact.php",
    "~^/?tos(/.*|\?.*|#.*)?$~" => $_SERVER["DOCUMENT_ROOT"]. "/components/tos.php",
    "~^/?privacy-policy(/.*|\?.*|#.*)?$~" => $_SERVER["DOCUMENT_ROOT"]. "/components/privacy-policy.php",
    "~^/?404(/.*|\?.*|#.*)?$~" => $_SERVER["DOCUMENT_ROOT"]. "/components/404.php"
);
global $PAGES_COMPONENTS;

$AUTH_REQUIRED_COMPONENTS = array($_SERVER["DOCUMENT_ROOT"]. "/components/dashboard.php");
global $AUTH_REQUIRED_COMPONENTS;

define("DEFAULT_PASS", ";){B@345_!aRg6");
define("SALT", "%JKB87#HJ%$5=:'~98|aa9bg");
define("PRODUCTS_PER_PAGE", 24);
define("REMEMBER_ME_LIFE_SPAN_IN_SECONDS", 86400 * 7);
define("MAX_TOTAL_IMAGE_SIZE_IN_MB", 1);
define("STATUS_OK", 200);
define("STATUS_BAD_REQUEST", 400);
define("STATUS_SERVER_ERROR", 503);
$MONEY_SYMBOLS = array("naira" => "&#8358;");
global $MONEY_SYMBOLS;

define("DISCOUNT", 30);
?>
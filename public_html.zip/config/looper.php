<?php
class Looper {
    private $items;
    private $list;
    private $index = 0;

    function __construct($list) {
        $this->items = "";
        $this->list = $list;
    }

    public function fillFromObject($object, $allowNewAttributes) {
        if(!$allowNewAttributes) {
            foreach($object as $attr => $value) {
                if(property_exists($this, $attr)) {
                    $this->$attr = $value;
                }
            }

        } else {
            foreach($object as $attr => $value) {
                $this->$attr = $value;
            }
        }
        return $this;
    }

    public function loop($what) {
        if($what == "products") {
            include_once($_SERVER["DOCUMENT_ROOT"]. "/config/functions.php");
            array_map(function ($product) {
                $this->items .= '
                <a href="'.productLink($product->title, $product->id).'" class="d-block no-expression product-grid-card col-xs-12 col-sm-6 col-md-3 btn-floating h-mb-15">
                    <div class="w-5 h-3 card-photo" style="background-image: url('.preg_split("~,~", $product->photos)[0].')">
                    </div>
                    <div class="details">
                        <div class="title">'.fakeHtml($product->title).'</div>
                        <div class="price">&#8358; <span data-type="number">'.$product->price.'</span><span class="scale"> per '.fakeHtml($product->scale).'</span></div>
                    </div>
                </a>';
                $this->index++;
            }, $this->list);

        } else if($what == "cats") {
            array_map(function ($item) {
                $this->items .= '<option value="'.$item->id.'">'.$item->name.'</option>';
                $this->index++;
            }, $this->list);

        } else if($what == "carousel-images") {
            array_map(function($item) {
                $this->items .= 
                '<div style="background:#000;border: 1px solid #dfdfdf" class="carousel-item'.($this->index == 0?" active":"").'">
                    <img style="height: 250px;width: auto;margin:0px auto" class="d-block" src="'.$item.'">
                </div>';
                $this->index++;
            }, $this->list);

        } else if($what == "carousel-thumbs") {
            array_map(function($item) {
                if($this->index + 1 == $this->maxthumbs && count($this->list) > $this->maxthumbs) {
                    $remainder = count($this->list) - ($this->index + 1);
                    $this->items .= 
                    '<li class="thumb" onClick="" data-target="#'.$this->target.'" data-slide-to="'.$this->index.'"'.($this->index == 0?' class="active"':'').'>
                        <img class="d-block w-100" style="position:absolute;height:70px;" src="'.$item.'"/>
                        <div class="d-block w-100 text-center font-weight-bold" 
                        style="height:70px;padding: 10px 5px;position:absolute;background:#000;opacity:.7;color:#fff;font-size:30px;">
                            + '.$remainder.'
                        </div>
                    </li>';

                } else if($this->index + 1 > $this->maxthumbs) {
                    $this->items .= '';

                } else {
                    $this->items .= 
                    '<li class="thumb" data-target="#'.$this->target.'" data-slide-to="'.$this->index.'"'.($this->index == 0?' class="active"':'').'>
                        <img style="height:70px;" class="d-block w-100" src="'.$item.'"/>
                    </li>';
                }
                
                $this->index++;
            }, $this->list);
        }
        return $this->items;
    }
}
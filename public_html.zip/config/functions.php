<?php
function get_header($session) {
    require_once("header.php");
}
function get_page($session) {
    require($_SERVER["DOCUMENT_ROOT"]. "/config/constants.php");
    $pageRequirement = null;
    if(isset($_GET["page"]) && !empty($_GET["page"])) {
        $pageRequirement = matched_key_value($_GET["page"], $PAGES_COMPONENTS);

    } else {
        $pageRequirement = matched_key_value("/", $PAGES_COMPONENTS);
    }
    
    if($pageRequirement == null) {
        $pageRequirement = matched_key_value("/404", $PAGES_COMPONENTS);

    } else if($session->user == null && in_array($pageRequirement, $AUTH_REQUIRED_COMPONENTS)) {
        $pageRequirement = matched_key_value("/signin", $PAGES_COMPONENTS);

    }
    $pageRequirementOutput = require_once($pageRequirement);
    if($pageRequirementOutput == null) {
        $pageRequirementOutput = require_once(matched_key_value("/404", $PAGES_COMPONENTS));

    }
    return $pageRequirementOutput;
    
}
function passwordHash($password) {
    require_once($_SERVER["DOCUMENT_ROOT"]. "/config/constants.php");
    return md5(trim($password).SALT);
}
function randomName($length){
    $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $str = '';
    while(strlen($str) < $length){
        $str .= substr(str_shuffle($chars), 0, 1);
    }
    return $str;
}
function hideRegexSymbols($text) {
    $symbols = array(
        "\\", ".", "^", "$", "[", "]", "-", "(", ")", "{", "}", 
        "|", "?", "*", "+", "!"
    );
    foreach($symbols as $value) {
        $text = str_replace($value, "\\".$value, $text);
    }
    return $text;
}
function matched_key_value($text, $array) {
    foreach($array as $pattern_key => $value) {
        if (preg_match($pattern_key, $text)){
            return $value;
        }
    }
    return null;
}
function get_footer() {
    require_once("footer.php");
}
function fakeHtml($text) {
    return htmlspecialchars($text, ENT_QUOTES);
}
function uploadFiles($files, $dest_folder, $totalMaxSize, $acceptedMimes){
    $uploaded = array();
    $errors = array();
    $usedSpace = 0;
    for($i = 0; $i < count($files["name"]); $i++) {
        if($files["error"][$i] > 0) {
            $errors[] = "An error occured while uploading the file at index $i";

        } else {
            $width = 1; $height = 1;
            if(startsWith($files["type"][$i], "image/")) {
                list($width, $height, $type, $attr) = getimagesize($files["tmp_name"][$i]);
            }
            if($usedSpace + $files["size"][$i] > $totalMaxSize) {
                $errors[] = "You exceeded the maximum size of file allowed when trying to upload the file at index $i";

            } else if(!in_array($files["type"][$i], $acceptedMimes) || $width < 1 || $height < 1) {
                $errors[] = "The file at index $i is not supported";

            } else {
                $filename = getFilename($files["type"][$i]);
                if(move_uploaded_file($files["tmp_name"][$i], $_SERVER['DOCUMENT_ROOT'].$dest_folder.$filename)){
                    $uploaded[] = $dest_folder.$filename;
                    $usedSpace += $files["size"][$i];
                }
            }
        }
    }
    return array("uploaded" => $uploaded, "errors" => $errors);
}
function getFilename($mime) {
    $filename = md5(randomName(12).strval(round(microtime(true) * 1000)));
    switch($mime) {
        case "image/jpeg":
        case "image/jpg":
            $filename .= ".jpg";
        break;
        case "image/png":
            $filename .= ".png";
    }
    return $filename;
}
function startsWith ($string, $startString) 
{ 
    $len = strlen($startString); 
    return (substr($string, 0, $len) === $startString); 
} 
function endsWith($string, $endString) 
{ 
    $len = strlen($endString); 
    if ($len == 0) { 
        return true; 
    } 
    return (substr($string, -$len) === $endString); 
}
function contains($haystack, $needle, $sentitive) {
    if(!$sentitive) {
        return stripos($haystack, $needle) !== false;

    } else {
        return strpos($haystack, $needle) !== false;
    }
}
function andQuery($newQuery, $query) {
    return contains($query, "WHERE", true)?" AND ".$newQuery:" WHERE ".$newQuery;
}
function orQuery($newQuery, $query) {
    return contains($query, "WHERE", true)?" OR ".$newQuery:" WHERE ".$newQuery;
}
function orderQuery($newQuery, $query) {
    return contains($query, "ORDER BY", true)?", ".$newQuery:" ORDER BY ".$newQuery;
}
function productLink($title, $id) {
    $title = trim($title);
    $title = preg_replace("~[\s\.]+~", "-", $title);
    $title = preg_replace("~[^-\dA-Z-a-z]+~", "", $title);
    $title = preg_replace("~-{2,}~", "-", $title);
    if(startsWith($title, "-"))$title = substr($title, 1);
    if(endsWith($title, "-"))$title = substr($title, 0, strlen($title) - 1);
    return strtolower("/products/".$title."/".$id);
}
function getEXT($filename, $includeDot){
    $index = strrpos($filename, ".");
    if(!$includeDot){
        $index++;
    }
    return substr($filename, $index);
}
function mimeFromFilename($filename) {
    $ext = getEXT($filename, true);
    $mimeExtArray = array(".jpg" => "image/jpeg", ".png" => "image/png");
    $mime = $mimeExtArray[strtolower($ext)];
    if($mime) {
        return $mime;

    } else {
        return "";
    }
}
function isValidCaptcha($captcta) {
    return true;
}
function isValidEmail($email) {
    return true;
}
function isValidPhoneNumber($number) {
    return true;
}
?>
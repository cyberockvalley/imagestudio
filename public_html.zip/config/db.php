<?php
include_once 'constants.php';
include_once($_SERVER["DOCUMENT_ROOT"]. "/models/cat.php");
include_once($_SERVER["DOCUMENT_ROOT"]. "/models/product.php");
class Database{
	
    private $conn;

    function __construct() {
        $this->startConnection();
    }
 
    // start the database connection
    private function startConnection(){
 
        $this->conn = null;
 
        $this->conn = new mysqli("localhost", USER, PASSWORD, DATABASE);
    }

    public function getConnection() {
        return $this->conn;
    }

    public function get_similar_products($id, $catId) {
        $stmt = $this->conn->prepare("SELECT * FROM products WHERE id != ? AND cat_id = ?");
        $stmt->bind_param('ii', $id, $catId);
        $stmt->execute();
        $result = $stmt->get_result();
        $catName = null;
        $catDesc = null;
        $returnValue = null;
        $list = array();
        $status = 0;
        //print_r($stmt);
        //echo "Q: $query | rows: ".$result->num_rows;
        if($result->num_rows > 0) {
            $status = 1;
            while($row = $result->fetch_object()) {
                $product = new Product();
                $product->fillFromObject($row);
                $list[] = $product;
            }
        }
        $stmt->close();

        return array("status" => $status, "list" => $list);

    }

    public function get_products($page, $searchPhrase, $catId) {
        $queryStart = "SELECT products.*, cats.name as cat_name FROM products, cats WHERE ";
        $bindSearchPhrase = false;
        $bindCatId = false;
        $query = "";
        if($catId != null && !empty($catId) && trim($catId) != "-1") {
            $query .= " AND products.cat_id = ? AND cats.id = products.cat_id";
            $bindCatId = true;

        } else {
            $query .= " AND cats.id = products.cat_id";
        }
        if(isset($searchPhrase) && !empty($searchPhrase) && $searchPhrase != null) {
            $query .= " AND UPPER(title) LIKE ? AND cats.id = products.cat_id OR UPPER(title) LIKE ? AND cats.id = products.cat_id OR UPPER(title) LIKE ? AND cats.id = products.cat_id";
            $bindSearchPhrase = true;
        }
        if($page == null || !isset($page) || empty($page) || intval($page) < 1) {
            $page = 1;
        }
        $offset = (intval($page) - 1) * PRODUCTS_PER_PAGE;

        $query .= " ORDER BY last_update DESC LIMIT ?, ?";
        
        $query = $queryStart . substr($query, strlen(" AND"));
        //echo $query;

        $stmt = $this->conn->prepare($query);
        
        $product_per_page = PRODUCTS_PER_PAGE;
        if($bindCatId && $bindSearchPhrase) {
            $p1 = "%".$searchPhrase."%";
            $p2 = "%".$searchPhrase;
            $p3 = $searchPhrase."%";
            $stmt->bind_param("isssii", $catId, $p1, $p2, $p3, $offset, $product_per_page);

        } else if($bindCatId) {
            $stmt->bind_param("iii", $catId, $offset, $product_per_page);
            
        } else if($bindSearchPhrase) {
            $p1 = "%".$searchPhrase."%";
            $p2 = "%".$searchPhrase;
            $p3 = $searchPhrase."%";
            $stmt->bind_param("sssii", $p1, $p2, $p3, $offset, $product_per_page);
            
        } else {
            $stmt->bind_param("ii", $offset, $product_per_page);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        $catName = null;
        $catDesc = null;
        $returnValue = null;
        $list == null;
        $status = 0;
        //print_r($stmt);
        //echo "Q: $query | rows: ".$result->num_rows;
        if($result->num_rows > 0) {
            $list = array();
            $status = 1;
            while($row = $result->fetch_object()) {
                $product = new Product();
                $product->fillFromObject($row);
                $list[] = $product;
            }
        }
        $stmt->close();

        if($bindCatId) {
            $stmt = $this->conn->prepare("SELECT name, description FROM cats WHERE id = ?");
            $stmt->bind_param('i', intval($catId));
            $stmt->execute();
            $stmt->store_result();
            $stmt->bind_result($catName, $catDesc);
            $stmt->fetch();
            $stmt->close();
        }
        return array("status" => $status, "cat_name" => $catName, "cat_description" => $catDesc, "list" => $list);

    }
    public function get_cats() {
        $stmt = $this->conn->prepare("SELECT * FROM cats");
        $stmt->execute();
        $result = $stmt->get_result();
        if($result->num_rows == 0) {
            $stmt->close();
            return array("status" => 0, "list" => null);

        } else {
            $list = array();
            while($row = $result->fetch_object()) {
                $cat = new Cat();
                $cat->id = $row->id;
                $cat->name = $row->name;
                $cat->description = $row->description;
                $list[] = $cat;
            }
            $stmt->close();
            return array("status" => 1, "list" => $list);
        }
    }
}
<?php require_once(__DIR__ . "/config/constants.php");?>
<section id="footer">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a target="_blank" href="<?=FB_PAGE?>"><i class="fa fa-facebook"></i></a></li>
						<li class="list-inline-item"><a target="_blank" href="<?=TWITTER_PAGE?>"><i class="fa fa-twitter"></i></a></li>
						<li class="list-inline-item"><a target="_blank" href="<?=INSTA_PAGE?>"><i class="fa fa-instagram"></i></a></li>
						<li class="hide list-inline-item"><a target="_blank" href="<?=FB_PAGE?>"><i class="fa fa-google-plus"></i></a></li>
						<li class="list-inline-item"><a href="mailto:<?=CONTACT_EMAIL?>"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				</hr>
			</div>	
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
					<p><u><a href="/about"><?=SITE_FULL_NAME;?></a></u> is a Registered <?=COMPANY_TYPE;?> Company. Located at <?=COMPANY_ADDRESS;?></p>
					
					<p class="h6 link-underlined">
						<a class="text-green ml-2" href="/about" target="_blank">About Us</a>
						<a class="text-green ml-2" href="/privacy-policy" target="_blank">Privacy Policy</a>
						<a class="text-green ml-2" href="/contact-us" target="_blank">Contact Us</a>
					</p>
					<p class="h6">&copy All right Reversed.<a class="text-green ml-2" href="/" target="_blank"><?= SITE_NAME; ?></a></p>

					<p><?=CEO;?>, CEO</p>
				</div>
				</hr>
			</div>	
		</div>
	</section>
#reactjs with parse-server boiler plate

Helpful Links
---
- Parse error codes at:
[https://parseplatform.org/Parse-SDK-dotNET/api/html/T_Parse_ParseException_ErrorCode.htm](https://parseplatform.org/Parse-SDK-dotNET/api/html/T_Parse_ParseException_ErrorCode.htm)

- Learn about markdown at: [https://agea.github.io/tutorial.md/](https://agea.github.io/tutorial.md/)

- Parse custom page(email verification, password reset...) example link at:
[https://github.com/parse-community/parse-server/tree/ca286b7108197034a3ff02063a259ff12181a329/views](https://github.com/parse-community/parse-server/tree/ca286b7108197034a3ff02063a259ff12181a329/views)

- Parse js guide at: [https://docs.parseplatform.org/js/guide/](https://docs.parseplatform.org/js/guide/)
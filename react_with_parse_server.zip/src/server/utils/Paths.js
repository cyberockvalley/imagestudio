const Paths = [
    "/", "/user/home", "/admin/home", "/create", "/login", "/user/upload",
    "/auth-process/invalid-link", "/auth-process/verify-email-success",
    "/auth-process/password-reset-success", "/auth-process/choose-password"
]

export default Paths
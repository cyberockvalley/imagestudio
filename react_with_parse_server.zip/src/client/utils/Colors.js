const Colors = {
    color_primary: "#d6a047",
    color_primary_contrast: "#fff",
    window_background: "#fff",
    window_background_contrast: "#fff"
}

export default Colors
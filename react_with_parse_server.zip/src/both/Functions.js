export const isNullOrEmpty = value => {
    return !value || value.length == 0
}